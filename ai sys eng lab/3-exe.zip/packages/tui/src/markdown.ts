import { theme } from "./ansi.js";

/**
 * Minimal markdown → ANSI renderer for terminal output. Supports headings,
 * bullets, bold, italic, inline code, and fenced code blocks. Not a full
 * parser — just enough to make LLM answers read well in a terminal.
 */
export function renderMarkdown(md: string): string {
    const lines = md.split("\n");
    const out: string[] = [];
    let inFence = false;

    for (const raw of lines) {
        if (/^\s*```/.test(raw)) {
            inFence = !inFence;
            continue; // drop the fence line itself
        }
        if (inFence) {
            out.push(theme.dim(raw));
            continue;
        }

        let line = raw;

        // Headings: strip leading #'s, bold the text.
        const heading = /^(#{1,6})\s+(.*)$/.exec(line);
        if (heading) {
            out.push(theme.bold(theme.primary(heading[2] ?? "")));
            continue;
        }

        // Bullets: -, *, + -> •
        const bullet = /^(\s*)[-*+]\s+(.*)$/.exec(line);
        if (bullet) {
            line = `${bullet[1]}\u2022 ${bullet[2]}`;
        }

        out.push(renderInline(line));
    }

    return out.join("\n");
}

/** Apply inline styles: **bold**, *italic*, `code`. */
function renderInline(s: string): string {
    let out = s;
    out = out.replace(/\*\*([^*]+)\*\*/g, (_m, t) => theme.bold(t));
    out = out.replace(/(?<!\*)\*([^*]+)\*(?!\*)/g, (_m, t) => theme.italic(t));
    out = out.replace(/`([^`]+)`/g, (_m, t) => theme.cyan(t));
    return out;
}
