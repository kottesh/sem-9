import { describe, it, expect, vi } from "vitest";
import { CappyUI } from "./cappyUI.js";

describe("CappyUI", () => {
    it("renders without throwing for each surface", () => {
        const log = vi.spyOn(console, "log").mockImplementation(() => {});
        const ui = new CappyUI();
        ui.banner();
        ui.info("info");
        ui.warn("warn");
        ui.error("err");
        ui.assistant("**hi** there");
        ui.fileView("resume.md", "line1\nline2");
        ui.bashResult("echo x", { stdout: "x\n", stderr: "", exitCode: 0, timedOut: false, truncated: false, requestedTimeoutMs: 5000 });
        ui.suggestions(["quantify impact", "use action verbs"]);
        expect(log).toHaveBeenCalled();
        log.mockRestore();
    });
});
