import type { AgentIO } from "@agent/core";
import { LineReader, StreamWriter, ThinkingView, renderMarkdown, speakerLine, notice, errorLine, theme } from "@agent/tui";
import type { CappyUI } from "./cappyUI.js";

/**
 * Terminal IO for the agent loop. Streams thinking into a dim block and the
 * final answer as it arrives; renders markdown once the full answer is known.
 */
export class CappyIO implements AgentIO {
    private readonly reader = new LineReader();
    private thinkingView: ThinkingView | null = null;
    private answer = new StreamWriter();
    private buffer = "";
    private headerPrinted = false;

    constructor(private readonly ui: CappyUI) {}

    input(prompt: string): Promise<string | null> {
        return this.reader.question(prompt);
    }

    /** Live thinking delta. */
    onThinking(delta: string): void {
        if (!this.thinkingView) this.thinkingView = new ThinkingView();
        this.thinkingView.thinking(delta);
    }

    /** Live answer token. */
    onToken(delta: string): void {
        // Close any thinking block before the answer starts.
        if (this.thinkingView?.active) this.thinkingView.endThinking();
        if (!this.headerPrinted) {
            process.stdout.write(speakerLine("cappy", ""));
            process.stdout.write("\n");
            this.headerPrinted = true;
        }
        this.buffer += delta;
        this.answer.write(delta);
    }

    /** Called at end of a streamed turn to finalize output. */
    finishStream(): void {
        this.answer.end();
        this.answer = new StreamWriter();
        this.buffer = "";
        this.headerPrinted = false;
        this.thinkingView = null;
    }

    printAssistant(text: string): void {
        // Non-streamed fallback path.
        if (this.headerPrinted) {
            this.finishStream();
            return;
        }
        console.log(speakerLine("cappy", ""));
        console.log(renderMarkdown(text));
    }

    printInfo(text: string): void {
        console.log(notice(text));
    }

    printError(text: string): void {
        console.log(errorLine(text));
    }

    onToolStart(name: string): void {
        console.log(theme.dim(`  \u2699 ${name}\u2026`));
    }

    close(): void {
        this.reader.close();
    }
}
