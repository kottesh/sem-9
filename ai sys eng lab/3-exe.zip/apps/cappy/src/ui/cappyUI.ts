import { banner, speakerLine, notice, warn, errorLine, bulletList, box, renderMarkdown, theme } from "@agent/tui";

export interface BashResultView {
    stdout: string;
    stderr: string;
    exitCode: number | null;
    timedOut: boolean;
    truncated: boolean;
    requestedTimeoutMs: number;
}

/** The concrete UI surface for cappy, composed from @agent/tui blocks. */
export class CappyUI {
    banner(): void {
        console.log(banner("cappy \u2014 resume review agent"));
    }

    info(text: string): void {
        console.log(notice(text));
    }

    warn(text: string): void {
        console.log(warn(text));
    }

    error(text: string): void {
        console.log(errorLine(text));
    }

    /** Print a full assistant message (non-streamed), rendered as markdown. */
    assistant(text: string): void {
        console.log(speakerLine("cappy", ""));
        console.log(renderMarkdown(text));
    }

    fileView(path: string, content: string): void {
        const lines = content.split("\n").map((l, i) => theme.dim(String(i + 1).padStart(3)) + " " + l);
        for (const row of box(lines, { title: path })) console.log(row);
    }

    bashResult(command: string, r: BashResultView): void {
        const status = r.timedOut
            ? theme.warn(`timed out after ${r.requestedTimeoutMs}ms`)
            : theme.dim(`exit ${r.exitCode}`);
        const lines: string[] = [];
        if (r.stdout.trim()) lines.push(...r.stdout.trimEnd().split("\n"));
        if (r.stderr.trim()) lines.push(...r.stderr.trimEnd().split("\n").map((l) => theme.error(l)));
        if (lines.length === 0) lines.push(theme.dim("(no output)"));
        if (r.truncated) lines.push(theme.dim("\u2026 (truncated)"));
        for (const row of box(lines, { title: `$ ${command}  ${status}` })) console.log(row);
    }

    suggestions(items: string[]): void {
        console.log(bulletList(items));
    }
}
